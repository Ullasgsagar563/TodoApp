package com.example.ToDoApp;

public class LoginDTO {
    public String username;
    public String password;
}
