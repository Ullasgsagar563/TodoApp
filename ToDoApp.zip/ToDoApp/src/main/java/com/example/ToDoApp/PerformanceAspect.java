package com.example.ToDoApp;

import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@Aspect
@Component
@RequiredArgsConstructor
public class PerformanceAspect {
    private final PerformansRepo repo;
    @Around("@within(org.springframework.web.bind.annotation.RestController)")
    public Object performanceTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long starttime=System.currentTimeMillis();
        Object result=joinPoint.proceed();
        long exe=System.currentTimeMillis()-starttime;
        PerformanceLog log= new PerformanceLog();
        log.setMethodName(joinPoint.getSignature().getName().toString());
        //log.setMethodName(joinPoint.getSignature().toString());
        log.setExeTime(exe);
        log.setTimestamp(LocalDateTime.now());
        System.out.println("exetime :"+exe);
        repo.save(log);
        //System.out.println("Ullas");
        return result;
    }

}
