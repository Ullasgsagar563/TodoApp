package com.example.ToDoApp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import org.aspectj.lang.annotation.Aspect;

import java.time.LocalDateTime;


@Entity
@Data
public class PerformanceLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    public  String methodName;
    public  long exeTime;
    public LocalDateTime timestamp;

}
