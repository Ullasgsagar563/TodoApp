package com.example.ToDoApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/performance-logs")
public class PerformansController {
    @Autowired
    private PerformansService service;
    public PerformansController(PerformansService performansService)
    {
        this.service=performansService;
    }
    @GetMapping()
    public List<PerformanceLog> getallperformans()
    {

        return service.getperformancelogs();
    }
}
