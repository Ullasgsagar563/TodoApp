package com.example.ToDoApp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PerformansRepo extends JpaRepository<PerformanceLog,Long> {
}
