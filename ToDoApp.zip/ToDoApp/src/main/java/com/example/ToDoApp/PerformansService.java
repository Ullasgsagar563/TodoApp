package com.example.ToDoApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PerformansService {
    @Autowired
    public  PerformansRepo repo;

    public List<PerformanceLog> getperformancelogs()
    {
        return repo.findAll();
    }
}
