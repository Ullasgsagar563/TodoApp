package com.example.ToDoApp;

public class RegDTO {
    public String username;
    public String password;
}
