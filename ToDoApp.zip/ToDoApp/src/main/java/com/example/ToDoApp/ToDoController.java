package com.example.ToDoApp;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.*;
import com.example.ToDoApp.ToDo;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/todos")
public class ToDoController {
    private ToDoService todoservice;
    public ToDoController(ToDoService todoservice)
    {
        this.todoservice=todoservice;
    }

    @GetMapping("/home")
    public String home() {
        return "welcome to your todos";
    }
    @GetMapping()
    public List<ToDo> getalltodos()
    {
        return todoservice.allgetToDos();
    }
    @GetMapping("/{id}")
    public ResponseEntity<ToDo> gettodoById(@PathVariable  int id)
    {
        //return todoservice.toDos.stream().filter(toDo -> toDo.getId()==id).findFirst();
        //todoservice.
        //return null;
        //return todoservice.repo.findById(id);
        ToDo todo=todoservice.getByDd(id);
        return ResponseEntity.ok(todo);
    }
    @PostMapping()
    public ResponseEntity<ToDo> addTodo(@Valid @RequestBody ToDo toDo)
    {
       ToDo newtodo= todoservice.addToDo(toDo);
       return new ResponseEntity<>(newtodo, HttpStatus.CREATED);
    }
    @PutMapping("/{id}")
    public  ResponseEntity<ToDo> updatetodo(@PathVariable int id, @Valid @RequestBody ToDo updatedtodo)
    {
        ToDo todo=todoservice.updateToDo(id,updatedtodo);
        if(todo!=null)
        {
            return ResponseEntity.ok(todo);
        }
        //
        return  ResponseEntity.ok(todo);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletetodo(@PathVariable int id) {
        todoservice.removetodo(id);
        return ResponseEntity.ok("deleted");
    }


}
