package com.example.ToDoApp;

import jakarta.persistence.Id;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ToDoService {
//    public List<ToDo> toDos=new ArrayList<>();
//    private int nextId=1;

    @Autowired
    public TodoRepo repo;


    public List<ToDo> allgetToDos() {
        return repo.findAll();
    }
    public ToDo addToDo(ToDo toDo)
    {
//        toDo.setId(nextId++);
//        toDos.add(toDo);
//        return  toDo;
        return repo.save(toDo);
    }
    public ToDo getByDd(int id)
    {
        return repo.findById(id).orElse(null);
    }

    public ToDo updateToDo(int id,ToDo update)
    {
//        Optional<ToDo> existing=toDos.stream().filter(toDo -> toDo.getId()==id).findFirst();
//        if(existing.isPresent())
//        {
//            ToDo todo=existing.get();
//            existing.get().setTitle(update.getTitle());
//            existing.get().setStatus(update.getStatus());
//            return  todo;
//        }
        //return null;
        repo.findById(id).map(toDo -> {toDo.setTitle(update.getTitle());
        toDo.setStatus(update.getStatus());
        return repo.save(toDo);
        }).orElse(null);
        //return repo.save(update);
        return null;
    }
    public void removetodo(int id)
    {
        //return repo.deleteById(id);
        //System.out.println();
        repo.deleteById(id);
        //return  true;


    }
}
