package com.example.ToDoApp;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface TodoRepo extends JpaRepository<ToDo, Integer> {

}
